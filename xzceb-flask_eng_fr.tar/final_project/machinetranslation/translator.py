import json
from ibm_watson import LanguageTranslatorV3
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
import os
from dotenv import load_dotenv

load_dotenv()

apikey = os.environ['RIBOgwLLNR2NQBocMZqOLnhOXuX65jSCoyG8v3eCaQJT']
url = os.environ['https://api.us-south.language-translator.watson.cloud.ibm.com/instances/901f7c4b-04a0-48c6-b7b1-194dcf911d5c']

from ibm_watson import LanguageTranslatorV3
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator

authenticator = IAMAuthenticator('{38ee3731-c2f8-4cbf-ae03-932c5dac0488}')
language_translator = LanguageTranslatorV3(
    version='{2018-05-01}',
    authenticator=authenticator
)

language_translator.set_service_url('https://api.us-south.language-translator.watson.cloud.ibm.com/instances/901f7c4b-04a0-48c6-b7b1-194dcf911d5c')

def english_to_french(text1):
    '''
    This function translates english to french
    '''
    frenchtranslation = language_translator.translate(
        text=text1
        "model_id"='en-fr'
    ).get_result()
    return frenchtranslation.get("translations"[0].get("translation"))